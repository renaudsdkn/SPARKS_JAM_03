Please read this first carefully before installing the font.

-This font is for PERSONAL USE ONLY and NO COMMERCIAL USE ALLOWED. If you make money with my font please purchase the license to: https://fikryalstudio.com/product/serenata-vantages-elegant-sans/
-For more information please contact my email: mfikryalif@gmail.com or visit: https://fikryalstudio.com
-Any misuse of the license will be subject to worldwide corporate fees.

-Link to purchase commercial license with an option: https://fikryalstudio.com/product/serenata-vantages-elegant-sans/
-Link Donation (PayPal) : fikryalif93@gmail.com

Thank you for download and your appreciated.
Keep Support our work and Happy Design !!

INDONESIA :
Hallo Fikryal Studio font downloader,
Sebelum anda mendownload tolong baca terlebih dahulu deskripsi dibawah ini.
Penjelasan ini merupakan bagian term and condition dari Fikryal Studio. Segala bentuk penyalahgunaan lisensi font dapat dikenai sanksi hukum.
Dengan mendownload font ini, Anda dianggap mengerti dan menyetujui semua syarat dan ketentuan penggunaan font dibawah ini:

1. Font ini hanya dapat digunakan untuk keperluan "Personal Use" atau penggunaanya bersifat individual yang tidak menghasilkan profit atau keuntungan. Untuk kepentingan yang bersifat kelompok, font ini hanya bisa digunakan untuk keperluan acara keagamaan serta kegiatan sosial (tidak menghasilkan keuntungan) .

2. DILARANG KERAS menggunakan atau memanfaatkan font ini untuk keperluan Komersial, baik itu untuk Iklan, Promosi, TV, Film, Video, Motion Graphics, Youtube, atau untuk Kemasan Produk ( baik Fisik ataupun Digital) atau Media apapun dengan tujuan menghasilkan profit/keuntungan.

3. Setiap bentuk penyalahgunaan Lisensi Fikryal Studio (Penggunaan tanpa izin lisensi , penggunaan font tidak sesuai lisensi) akan kami kenakan biaya sebesar Lisensi Perusahaan (Wordwide Corporate License). Atau dapat kami tempuh melalui jalur hukum sesuai Undang-Undang Nomor 28 Tahun 2014 Tentang Hak Cipta.

4. Segala Bentuk konten dan kekayaan intelektual Fikryal Studio dilindungi oleh Negara dan setiap pelanggaran yang akan menempuh jalur hukum akan ditangani oleh tim legal dari Perkumpulan Desainer Huruf Indonesia (PDHI).